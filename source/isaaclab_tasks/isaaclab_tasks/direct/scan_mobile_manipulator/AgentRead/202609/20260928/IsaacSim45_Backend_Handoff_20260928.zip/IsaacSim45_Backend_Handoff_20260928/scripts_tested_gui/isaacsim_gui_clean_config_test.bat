@echo off
setlocal EnableExtensions DisableDelayedExpansion

REM Run from Anaconda Prompt. This script changes no packages or drivers.
REM Only the user.config.json location changes; Vulkan remains selected.
set "TARGET_ENV=C:\isaacenvs\isaac45"

echo [1/4] Activating the existing environment...
call conda activate "%TARGET_ENV%"
if errorlevel 1 (
    echo [ERROR] Activation failed. Please run this file from Anaconda Prompt.
    pause
    exit /b 1
)
if not exist "%TARGET_ENV%\Scripts\isaacsim.exe" (
    echo [ERROR] Isaac Sim executable not found.
    pause
    exit /b 1
)

set "PYTHONUTF8=1"
set "PYTHONFAULTHANDLER=1"
set "PYTHONUNBUFFERED=1"
set "TEST_DIR=%USERPROFILE%\isaacsim_gui_clean_%RANDOM%_%RANDOM%"
if exist "%TEST_DIR%" (
    echo [ERROR] Output directory already exists. Run this script again.
    pause
    exit /b 1
)
mkdir "%TEST_DIR%"
if errorlevel 1 (
    echo [ERROR] Could not create the test directory.
    pause
    exit /b 1
)

REM Use a new, empty persistent-settings file. Do not touch the old one.
> "%TEST_DIR%\user.config.json" echo {}
if errorlevel 1 (
    echo [ERROR] Could not create the test configuration.
    pause
    exit /b 1
)

echo [2/4] Recording test settings...
> "%TEST_DIR%\test_info.txt" echo Started: %DATE% %TIME%
>> "%TEST_DIR%\test_info.txt" echo Environment: %TARGET_ENV%
>> "%TEST_DIR%\test_info.txt" echo Experience: isaacsim.exp.full
>> "%TEST_DIR%\test_info.txt" echo Graphics API requested: Vulkan
>> "%TEST_DIR%\test_info.txt" echo User config: %TEST_DIR%\user.config.json
"%TARGET_ENV%\python.exe" -c "import sys; from importlib.metadata import version; print('Python:', sys.executable); print('UTF8 mode:', sys.flags.utf8_mode); [print(n + ': ' + version(n)) for n in ('isaacsim','torch','numpy','scipy','osqp','qdldl','h5py')]" >> "%TEST_DIR%\test_info.txt" 2>&1
nvidia-smi --query-gpu=name,driver_version --format=csv >> "%TEST_DIR%\test_info.txt" 2>&1

echo [3/4] Launching Isaac Sim with a separate user configuration...
echo Logs: "%TEST_DIR%"
echo Console output goes to gui_console.txt while this window waits.
echo If the GUI stays responsive, test it briefly and then close it normally.
echo This script does not stop the GUI automatically.

"%TARGET_ENV%\Scripts\isaacsim.exe" isaacsim.exp.full --vulkan "--/app/userConfigPath=%TEST_DIR%\user.config.json" > "%TEST_DIR%\gui_console.txt" 2>&1
set "ISAAC_EXITCODE=%ERRORLEVEL%"
>> "%TEST_DIR%\gui_console.txt" echo EXITCODE=%ISAAC_EXITCODE%
>> "%TEST_DIR%\test_info.txt" echo Finished: %DATE% %TIME%
>> "%TEST_DIR%\test_info.txt" echo EXITCODE=%ISAAC_EXITCODE%

echo [4/4] Isaac Sim exited. EXITCODE=%ISAAC_EXITCODE%
echo Reading recent Windows application-error events, if available...
powershell -NoProfile -Command "$ev = Get-WinEvent -FilterHashtable @{LogName='Application'; Id=1000,1001; StartTime=(Get-Date).AddMinutes(-15)} -ErrorAction SilentlyContinue; $matches = @($ev | Where-Object { $_.Message -match '(?i)(isaacsim|kit\.exe|python\.exe)' } | Select-Object -First 6); if ($matches.Count -gt 0) { $matches | Format-List TimeCreated,Id,ProviderName,Message | Out-String -Width 240 } else { Write-Output 'No matching recent application-error events were available. This does not prove that no crash occurred.' }" > "%TEST_DIR%\windows_app_errors.txt" 2>&1

echo Logs saved to: "%TEST_DIR%"
echo Original user settings, caches, packages, and drivers were not reset.
explorer "%TEST_DIR%"
pause
endlocal & exit /b %ISAAC_EXITCODE%
