"""Check Isaac Lab startup defaults without injecting a graphics override.

Target API: Isaac Lab 2.1.1 / Isaac Sim 4.5 on Windows.
Run in the same Python environment as the actual project:
    python check_isaaclab_runtime_defaults.py --device cuda:0
    python check_isaaclab_runtime_defaults.py --device cuda:0 --headless

This is an empty-scene startup/step smoke test, not a training or camera test.
The script does not install packages or modify Kit configuration files.
"""

import argparse
import sys

print(f"[CHECK] Python: {sys.executable}", flush=True)
print(f"[CHECK] UTF8 mode: {sys.flags.utf8_mode}", flush=True)
if sys.platform == "win32" and sys.flags.utf8_mode != 1:
    raise RuntimeError(
        "Enable PYTHONUTF8=1 before starting Python, then run this test again."
    )

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--steps", type=int, default=120)
AppLauncher.add_app_launcher_args(parser)
args_cli = parser.parse_args()
if args_cli.steps < 1:
    parser.error("--steps must be positive")
if getattr(args_cli, "kit_args", "").strip():
    parser.error("Omit --kit_args: this test checks the default configuration.")

# No D3D12/Vulkan override here: validate the default actually being loaded.
launcher = AppLauncher(args_cli)
simulation_app = launcher.app

try:
    # Omniverse runtime-dependent imports stay AFTER AppLauncher construction.
    import carb.settings
    import torch
    from isaaclab.sim import SimulationCfg, SimulationContext

    vulkan = carb.settings.get_settings().get("/app/vulkan")
    print(f"[CHECK] /app/vulkan = {vulkan!r}", flush=True)
    if sys.platform == "win32" and vulkan is not False:
        raise RuntimeError(
            "Expected /app/vulkan=False on this Windows machine. Check the "
            "shared user.toml location and any startup overrides. Also inspect "
            "the Graphics API line in the Kit log."
        )

    # Check a real operation, not just torch.cuda.is_available().
    device = torch.device(args_cli.device)
    x = torch.ones(32, dtype=torch.float32, device=device)
    value = (x * 2).sum().item()
    if value != 64.0:
        raise RuntimeError(f"Unexpected tensor result: {value}")
    print(f"[CHECK] TENSOR_OK device={x.device} result={value}", flush=True)

    # Explicitly forward the CLI device; do not silently use SimulationCfg defaults.
    cfg = SimulationCfg(dt=0.01, device=args_cli.device)
    sim = SimulationContext(cfg)
    sim.reset()
    print(f"[CHECK] SIM_RESET_OK device={cfg.device}", flush=True)

    completed = 0
    for _ in range(args_cli.steps):
        if not simulation_app.is_running():
            raise RuntimeError(f"App closed early after {completed} steps")
        sim.step()
        completed += 1
    print(f"[CHECK] STEP_OK steps={completed}", flush=True)
    print("[CHECK] TEST_BODY_OK; closing the simulator next.", flush=True)
finally:
    # Some Kit shutdown paths end the process; do not require a print after close().
    print("[CHECK] Closing simulator...", flush=True)
    simulation_app.close()
