# Vulkan 原生异常：Windows 事件记录的结构化摘录

> 这是对之前上传的 **Vulkan 失败运行 windows_app_errors.txt** 的字段摘录，不是完整原文件或重新采集的日志。
> 原报告中文标签存在乱码。以下仅将字段名整理为可读文字；时间、模块、代码、偏移、路径和 Report ID 按原文保留。
> 不要与 `06_d3d12_windows_events.txt` 混淆，后者属于后续成功运行，仅表示查询未返回匹配事件。

## 2026-09-28 11:30 的独立配置 Vulkan 测试

原文定位：之前上传的失败版 `windows_app_errors.txt`，第 40–51 行。

| 字段 | 原文记录 |
|---|---|
| TimeCreated | 2026/9/28 11:30:18 |
| Event ID | 1000 |
| ProviderName | Application Error |
| 故障应用 | python.exe |
| 应用版本 | 3.10.20150.1013 |
| 故障模块 | rtx.scenedb.plugin.dll |
| 异常代码 | 0xc0000005 |
| 模块内偏移 | 0x00000000000d6d4b |
| 进程 ID | 0x2814 |
| Report ID | b1ab3ef3-711a-45d4-b96c-0a4e5342c2be |

故障应用路径：

```text
C:\isaacenvs\isaac45\python.exe
```

故障模块路径：

```text
c:\isaacenvs\isaac45\lib\site-packages\isaacsim\extscache\omni.hydra.rtx-1.0.0+d02c707b.wx64.r\bin\deps\rtx.scenedb.plugin.dll
```

## 2026-09-28 11:17 的原用户配置运行

原文定位：同一份失败版 `windows_app_errors.txt`，第 92–103 行。

| 字段 | 原文记录 |
|---|---|
| TimeCreated | 2026/9/28 11:17:07 |
| Event ID | 1000 |
| ProviderName | Application Error |
| 故障应用 | python.exe |
| 故障模块 | rtx.scenedb.plugin.dll |
| 异常代码 | 0xc0000005 |
| 模块内偏移 | 0x00000000000d6d4b |
| 进程 ID | 0x50BC |
| Report ID | a297493e-8014-4433-8e3b-97e995218068 |

故障应用和模块路径与 11:30 记录相同。

## 解释边界

两次 Windows 记录具有相同模块、异常代码和模块内偏移。该证据定位的是发生异常的原生组件，不等于已证明 DLL 自身、驱动、显存或某个 Python 菜单模块是唯一根因。

完整原报告仍可由用户从失败测试目录补充：

```text
C:\Users\33506\isaacsim_gui_clean_17041_8848\windows_app_errors.txt
```

本交接包没有将后续成功运行的同名空事件记录冒充为这份失败原报告。
