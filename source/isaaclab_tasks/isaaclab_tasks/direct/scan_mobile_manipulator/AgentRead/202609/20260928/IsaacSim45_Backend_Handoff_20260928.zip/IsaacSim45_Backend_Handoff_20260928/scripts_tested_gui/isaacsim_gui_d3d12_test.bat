@echo off
setlocal EnableExtensions DisableDelayedExpansion

REM Run this file from Anaconda Prompt.
REM Diagnostic only: no package installation, driver change, or cache deletion.
REM Compared with the previous clean-config test, disable Vulkan on Windows.
set "TARGET_ENV=C:\isaacenvs\isaac45"

echo [1/4] Activating the existing environment...
call conda activate "%TARGET_ENV%"
if errorlevel 1 (
    echo [ERROR] Activation failed. Run this file from Anaconda Prompt.
    pause
    exit /b 1
)
if not exist "%TARGET_ENV%\Scripts\isaacsim.exe" (
    echo [ERROR] Isaac Sim executable not found in the target environment.
    pause
    exit /b 1
)

set "PYTHONUTF8=1"
set "PYTHONFAULTHANDLER=1"
set "PYTHONUNBUFFERED=1"
set "TEST_DIR=%USERPROFILE%\isaacsim_dx12_%RANDOM%_%RANDOM%"
if exist "%TEST_DIR%" (
    echo [ERROR] Output directory already exists. Run this script again.
    pause
    exit /b 1
)
mkdir "%TEST_DIR%"
if errorlevel 1 (
    echo [ERROR] Could not create the output directory.
    pause
    exit /b 1
)
> "%TEST_DIR%\user.config.json" echo {}
if errorlevel 1 (
    echo [ERROR] Could not create the test user configuration.
    pause
    exit /b 1
)

echo [2/4] Recording environment and test settings...
> "%TEST_DIR%\test_info.txt" echo Started: %DATE% %TIME%
>> "%TEST_DIR%\test_info.txt" echo Environment: %TARGET_ENV%
>> "%TEST_DIR%\test_info.txt" echo Experience: isaacsim.exp.full
>> "%TEST_DIR%\test_info.txt" echo Setting override: /app/vulkan=false
>> "%TEST_DIR%\test_info.txt" echo Expected graphics API on Windows: D3D12; verify actual value in console log.
>> "%TEST_DIR%\test_info.txt" echo User config: %TEST_DIR%\user.config.json
"%TARGET_ENV%\python.exe" -c "import sys; from importlib.metadata import version; print('Python:', sys.executable); print('UTF8 mode:', sys.flags.utf8_mode); [print(n + ': ' + version(n)) for n in ('isaacsim','torch','numpy','scipy','osqp','qdldl','h5py')]" >> "%TEST_DIR%\test_info.txt" 2>&1
nvidia-smi --query-gpu=name,driver_version --format=csv >> "%TEST_DIR%\test_info.txt" 2>&1

echo [3/4] Launching Isaac Sim with Vulkan disabled...
echo Output directory: "%TEST_DIR%"
echo The console output is redirected to gui_console.txt.
echo Wait for the GUI. If it stays responsive, test menus and the viewport,
echo then close it normally. This script will not close it automatically.

REM Do not add --vulkan here; that would contradict the test setting.
"%TARGET_ENV%\Scripts\isaacsim.exe" isaacsim.exp.full --/app/vulkan=false "--/app/userConfigPath=%TEST_DIR%\user.config.json" > "%TEST_DIR%\gui_console.txt" 2>&1
set "ISAAC_EXITCODE=%ERRORLEVEL%"
>> "%TEST_DIR%\gui_console.txt" echo EXITCODE=%ISAAC_EXITCODE%
>> "%TEST_DIR%\test_info.txt" echo Finished: %DATE% %TIME%
>> "%TEST_DIR%\test_info.txt" echo EXITCODE=%ISAAC_EXITCODE%

echo [4/4] Isaac Sim exited. EXITCODE=%ISAAC_EXITCODE%
echo Actual graphics API reported by Kit:
findstr /C:"Graphics API:" "%TEST_DIR%\gui_console.txt"
findstr /C:"Graphics API:" "%TEST_DIR%\gui_console.txt" >> "%TEST_DIR%\test_info.txt"
echo Reading recent Windows application-error events...
REM Write the event report explicitly as UTF-8, avoiding console-codepage conversion.
powershell -NoProfile -Command "$out = Join-Path $env:TEST_DIR 'windows_app_errors.txt'; try { $ev = Get-WinEvent -FilterHashtable @{LogName='Application'; Id=1000,1001; StartTime=(Get-Date).AddMinutes(-15)} -ErrorAction SilentlyContinue; $m = @($ev | Where-Object { $_.Message -match '(?i)(isaacsim|kit\.exe|python\.exe)' } | Select-Object -First 6); if ($m.Count -gt 0) { $text = $m | Format-List TimeCreated,Id,ProviderName,Message | Out-String -Width 260 } else { $text = 'No matching recent events were available. This does not prove that no crash occurred.' }; [IO.File]::WriteAllText($out, $text, (New-Object System.Text.UTF8Encoding($false))) } catch { [IO.File]::WriteAllText($out, ('Event query failed: ' + $_.Exception.Message), (New-Object System.Text.UTF8Encoding($false))) }" > "%TEST_DIR%\event_query_console.txt" 2>&1

echo Logs saved to: "%TEST_DIR%"
echo No packages, drivers, original user configuration, or caches were reset.
explorer "%TEST_DIR%"
pause
endlocal & exit /b %ISAAC_EXITCODE%
