# 文件索引与来源

此包是 2026-09-28 本窗口已有材料的整理，不含新的 Isaac Sim 运行结果，也不含 Codex 当前评估报告。

| 包内文件 | 来源/状态 |
|---|---|
| `00_README_HANDOFF.md` | 本次整理的交接说明；先读 |
| `evidence/01_environment_isaac45.txt` | 用户上传 `environment.txt` 的原始字节副本；GUI 环境，不是 HARL 环境 |
| `evidence/02_vulkan_gui_failed.txt` | 用户上传 `gui_console(1).txt` 原始副本；11:30 独立配置 Vulkan 失败 |
| `evidence/03_vulkan_test_info.txt` | 用户上传 `test_info.txt` 原始副本；11:30 失败测试参数 |
| `evidence/04_vulkan_windows_error_excerpt.md` | 根据此前上传的失败版 Windows 事件报告整理的字段摘录；不是完整原日志 |
| `evidence/05_d3d12_gui_passed.txt` | 用户最后上传的成功版 `gui_console.txt` 原始副本；11:37 D3D12，退出码 0 |
| `evidence/06_d3d12_windows_events.txt` | 成功测试的事件查询输出原始副本，仅作辅助 |
| `scripts_tested_gui/isaacsim_gui_clean_config_test.bat` | 本窗口提供的独立配置 Vulkan 诊断脚本，已有对应失败结果 |
| `scripts_tested_gui/isaacsim_gui_d3d12_test.bat` | 本窗口提供的 D3D12 对照脚本，已有对应 GUI 成功结果 |
| `proposed_not_validated/check_isaaclab_runtime_defaults.py` | 上一窗口提供的代码启动检查脚本；未收到用户运行结果，不是项目正式入口 |

两个 GUI 测试脚本都从新建的空 `user.config.json` 开始，运行后会产生大量持久化设置。为减少体积及个人路径披露，本包不附那两份庞大的 JSON；不能将它们当成 D3D12 默认设置已经安装的证明。

部分原始测试记录有中文编码显示问题；保留原始字节，没有为“好看”而改写日志。
